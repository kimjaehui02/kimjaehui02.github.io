#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <conio.h>
#include <Windows.h>

#include <list>

using namespace std;

void draw(char* loc, const char* face)
{
	strncpy(loc, face, strlen(face));
}

class Screen
{
	int size;
	char* screen;

public:
	Screen(int sz) : size(sz), screen(new char[sz + 1])
	{
	}
	~Screen()
	{
		delete[] screen;
	}

	void draw(int pos, const char* face)
	{
		if(face == nullptr) return;
		if(pos < 0 || pos >= size) return;
		strncpy(&screen[pos], face, strlen(face));
	}

	void render()
	{
		printf("%s\r", screen);
	}

	void clear()
	{
		memset(screen, ' ', size);
		screen[size] = '\0';
	}

	int length()
	{
		return size;
	}

};

class GameObject
{
protected :
	int pos;
	char face[20];
	Screen* screen;

public:
	GameObject(int pos, const char* face, Screen* screen)
		: pos(pos), screen(screen)
	{
		strcpy(this->face, face);
	}


	int getPosition()
	{
		return pos;
	}
	void setPosition(int pos)
	{
		this->pos = pos;
	}

	virtual void draw()
	{
		screen->draw(pos, face);
	}
};

class Player : public GameObject
{
private :
	const char *leftface;
	const char *rightface;

	bool LookLeft = false;

	int Player_HP;

public:
	Player(int pos, const char* face, Screen* screen)
		: GameObject(pos, face, screen), leftface("<-_-)")
		, rightface("(-_->"), Player_HP(5)
	{
	}

	bool  returnLookLeft()
	{
		return LookLeft;
	}

	virtual void draw()
	{
		if(LookLeft)
		{
			screen->draw(pos, leftface);
		}
		else
		{
			screen->draw(pos, rightface);
		}
	}

	void moveLeft()
	{
		LookLeft = true;
		setPosition(getPosition() - 1);
	}

	void moveRight()
	{
		LookLeft = false;
		setPosition(getPosition() + 1);
	}

	void update()
	{

	}

};

class Enemy : public GameObject
{
private :

	int movePoint;
	int Enemy_Hp;
public:
	Enemy(int pos, const char* face, Screen* screen)
		: GameObject(pos, face, screen), movePoint(0), Enemy_Hp(10)
	{
	}

	void Dameged()
	{
		Enemy_Hp--;
	}

	void moveRandom()
	{
		setPosition(getPosition() + rand() % 3 - 1);
	}

	void movePlayer(int player_pos)
	{
		if(pos < player_pos)
		{
			pos++;
		}
		else
		{
			pos--;
		}
	}

	void update(int player_pos)
	{
		if(Enemy_Hp > 0)
		{
			if(movePoint % 3 == 0)
			{
				movePlayer(player_pos);
			}
			movePoint++;
			//moveRandom();
		}
		else
		{
			pos = -10;
		}
	}
};

class Bullet : public GameObject
{
	bool isFiring;
	bool goLeft;

public:
	Bullet(int pos, const char* face, Screen* screen)
		: GameObject(pos, face, screen), isFiring(false), goLeft(false)
	{
	}

	void fireLeft(bool left)
	{
		this->goLeft = left;
	}

	bool returnIfFire()
	{
		return isFiring;
	}

	void moveLeft()
	{
		setPosition(getPosition() - 1);
	}

	void moveRight()
	{
		setPosition(getPosition() + 1);
	}

	void draw()
	{
		if(isFiring == false) return;
		GameObject::draw();
	}

	void fire(int player_pos)
	{
		isFiring = true;
		setPosition(player_pos);
	}

	void updateGO()
	{
		if(isFiring == false) return;
		int pos = getPosition();

		// ������ �� �Է¹��� ���� ���� �߻�Ǵ� �ڵ�
		if(goLeft == true)
		{
			pos = pos - 1;
		}
		else
		{
			pos = pos + 1;
		}
		setPosition(pos);
	}

	void update(int enemy_pos)
	{
		if(isFiring == false)
		{
			pos = -20;
			return;
		}
		int pos = getPosition();
		// ���� �����ϴ� źȯ�� �ڵ�
		/*
		if(pos < enemy_pos)
		{
			pos = pos + 1;
		}
		else if(pos > enemy_pos)
		{
			pos = pos - 1;
		}
		*/


		if (pos == enemy_pos || pos == 0 || pos == 80)
		{
			isFiring = false;
		}
		setPosition(pos);
	}
};

class Text : public GameObject
{
private :

public :
	Text(int pos, const char* face, Screen* screen)
		: GameObject(pos, face, screen)
	{
	}
};

int main()
{
	
	Screen screen{ 80 };

	Player player = { 30, "(^_^)", &screen };
	

	int bullet_in = 10;
	bool reroad = false;

	//Enemy enemy{ 60, "(*--*)", &screen };
#pragma region Enemy
	const int Army_size = 5;
	list<Enemy> Army;

	// �ʱ�ȭ
	for(int i = 0; i < Army_size; i++)
	{
		if(i % 2 == 0)
		{
			Army.push_back({ 70 - i * 5, "(*--*)", &screen });
		}
		else
		{
			Army.push_back({ i * 5, "(*--*)", &screen });
		}
	}

#pragma endregion

	//Player player = { 30, "(^_^)", &screen };
	//Enemy enemy{ 60, "(*--*)", &screen };
	//Bullet bullet(-1, "+", &screen);

#pragma region Bullet
	const int magazine_size = 10;
	list<Bullet> magazine;

	// �ʱ�ȭ
	for(int i = 0; i < magazine_size; i++)
	{
		magazine.push_back({ -1, "+", &screen });
	}
#pragma endregion

	while(true)
	{
		screen.clear();

		if(bullet_in == 0)
		{
			reroad = true;
		}

		if(_kbhit())
		{
			int c = _getch();
			switch(c)
			{
			case 'a':
				player.moveLeft();
				break;
			case 'd':
				player.moveRight();
				break;
			case ' ':
				reroad = false;
				if(bullet_in != 0)
				{
					for(auto iter = magazine.begin();
						iter != magazine.end();
						iter++)
					{
						if(iter->returnIfFire() == false)
						{
							iter->fireLeft(player.returnLookLeft());
							iter->fire(player.getPosition());
							bullet_in--;
							break;
						}
					}
				}
				break;
			}
		}


		if(reroad == true || bullet_in != 10)
		{
			bullet_in++;
		}

#pragma region Draw

		player.draw();


		//enemy.draw();

		for(auto iter = Army.begin();
			iter != Army.end();
			iter++)
		{
			iter->draw();
		}

		for(auto iter = magazine.begin();
			iter != magazine.end();
			iter++)
		{
			iter->draw();
		}

#pragma endregion

#pragma region Update

		player.update();

		//enemy.update(player.getPosition());

		for(auto iter = Army.begin();
			iter != Army.end();
			iter++)
		{
			iter->update(player.getPosition());
		}


		for(auto iter = magazine.begin();// �Ѿ˵�
			iter != magazine.end();
			iter++)
		{
			iter->updateGO();// �̵�
			for(auto iter2 = Army.begin();// ����
				iter2 != Army.end();
				iter2++)
			{
				iter->update(iter2->getPosition());// �Ҹ�

				if(iter->getPosition() == iter2->getPosition() ||
				   iter->getPosition()+1 == iter2->getPosition() ||
				   iter->getPosition()-1 == iter2->getPosition() ||
				   iter->getPosition()+2 == iter2->getPosition() ||
				   iter->getPosition()-2 == iter2->getPosition())//��Ĩ�� Ȯ���Ѵ�.
				{
					iter2->Dameged();// �������� �Դ´�
				}
			}

		}

#pragma endregion

		screen.render();
		Sleep(66);
	}

	return 0;
}
// 1. �÷��̾� ���⼺
// 2. ���ݽÿ� ���� ����
// 11. ȭ��� ���� �� �ִ� �� 5��
// 12. 2�ʴ� 1��ŭ�� �ӵ�
// 13. ��, �÷��̾��� ü��
// 15. ���ݹ����� ���� ����� ���

// �Ѿ� ���� 10�� ����